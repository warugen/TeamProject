package com.tj.sp.dto;

import java.sql.Date;

public class Review {
	private String rcode   ;
	private String rcontent;
	private int    rstar   ;
	private Date   rrdate  ;
	private String rimage  ;
	private String cid     ;
	private String pcode   ;
	private int    startrow;
	private int    endrow  ;
	public Review() {}
	public String getRcode() {
		return rcode;
	}
	public void setRcode(String rcode) {
		this.rcode = rcode;
	}
	public String getRcontent() {
		return rcontent;
	}
	public void setRcontent(String rcontent) {
		this.rcontent = rcontent;
	}
	public int getRstar() {
		return rstar;
	}
	public void setRstar(int rstar) {
		this.rstar = rstar;
	}
	public Date getRrdate() {
		return rrdate;
	}
	public void setRrdate(Date rrdate) {
		this.rrdate = rrdate;
	}
	public String getRimage() {
		return rimage;
	}
	public void setRimage(String rimage) {
		this.rimage = rimage;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getPcode() {
		return pcode;
	}
	public void setPcode(String pcode) {
		this.pcode = pcode;
	}
	public int getStartrow() {
		return startrow;
	}
	public void setStartrow(int startrow) {
		this.startrow = startrow;
	}
	public int getEndrow() {
		return endrow;
	}
	public void setEndrow(int endrow) {
		this.endrow = endrow;
	}
	@Override
	public String toString() {
		return "Review [rcode=" + rcode + ", rcontent=" + rcontent + ", rstar=" + rstar + ", rrdate=" + rrdate
				+ ", rimage=" + rimage + ", cid=" + cid + ", pcode=" + pcode + ", startrow=" + startrow + ", endrow="
				+ endrow + "]";
	}
	

}
